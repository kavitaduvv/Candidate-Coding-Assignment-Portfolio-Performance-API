﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace PortfolioAPI_NoDTO.Controllers;

[ApiController]
[Route("api/assets/{assetId}/transactions")]
public class TransactionController : ControllerBase
{
    private readonly AppDbContext _context;
    public TransactionController(AppDbContext context) => _context = context;

    [HttpGet]
    public async Task<IActionResult> Get(int assetId)
    {
        var txs = await _context.Transactions
            .Where(t => t.AssetId == assetId)
            .ToListAsync();

        return Ok(txs);
    }

    [HttpPost]
    public async Task<IActionResult> Create(int assetId, Transaction tx)
    {

        if (!ModelState.IsValid)
            return BadRequest(ModelState);


        tx.AssetId = assetId;
        _context.Transactions.Add(tx);
        await _context.SaveChangesAsync();
        return Ok(tx);
    }
}
