﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace PortfolioAPI_NoDTO.Controllers;

[ApiController]
[Route("api/portfolios/{portfolioId}/assets")]
public class AssetController : ControllerBase
{
    private readonly AppDbContext _context;
    public AssetController(AppDbContext context) => _context = context;

    [HttpGet]
    public async Task<IActionResult> Get(int portfolioId)
    {
        var assets = await _context.Assets
            .Where(a => a.PortfolioId == portfolioId)
            .Select(a => new { a.Id, a.Symbol, a.Type })
            .ToListAsync();

        return Ok(assets);
    }

    [HttpPost]
    public async Task<IActionResult> Create(int portfolioId, Asset asset)
    {

        if (!ModelState.IsValid)
            return BadRequest(ModelState);
        asset.PortfolioId = portfolioId;
        _context.Assets.Add(asset);
        await _context.SaveChangesAsync();
        return Ok(asset);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, Asset updated)
    {
        var asset = await _context.Assets.FindAsync(id);
        if (asset == null) return NotFound();

        asset.Symbol = updated.Symbol;
        asset.Type = updated.Type;
        await _context.SaveChangesAsync();

        return Ok(asset);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var asset = await _context.Assets.FindAsync(id);
        if (asset == null) return NotFound();

        _context.Assets.Remove(asset);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}
