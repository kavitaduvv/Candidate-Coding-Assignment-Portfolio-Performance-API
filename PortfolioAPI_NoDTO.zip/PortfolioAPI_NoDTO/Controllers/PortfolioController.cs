﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace PortfolioAPI_NoDTO.Controllers;

[ApiController]
[Route("api/portfolios")]
public class PortfolioController : ControllerBase
{
    private readonly AppDbContext _context;
    public PortfolioController(AppDbContext context) => _context = context;

    [HttpGet]
    public async Task<IActionResult> Get() =>
        Ok(await _context.Portfolios.ToListAsync());

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] Portfolio portfolio)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        _context.Portfolios.Add(portfolio);
        await _context.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = portfolio.Id }, portfolio);
    }

}
