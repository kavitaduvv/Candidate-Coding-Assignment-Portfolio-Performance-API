﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace PortfolioAPI_NoDTO.Controllers;

[ApiController]
[Route("api/portfolios/{portfolioId}/performance")]
public class PerformanceController : ControllerBase
{
    private readonly AppDbContext _context;

    public PerformanceController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetPerformance(
        int portfolioId,
        [FromQuery] DateTime startDate,
        [FromQuery] DateTime endDate)
    {
        var assets = await _context.Assets
            .Where(a => a.PortfolioId == portfolioId)
            .ToListAsync();

        if (!assets.Any())
            return NotFound("No assets found for this portfolio.");

        var assetIds = assets.Select(a => a.Id).ToList();

        var transactions = await _context.Transactions
            .Where(t => assetIds.Contains(t.AssetId) && t.Date <= endDate)
            .ToListAsync();

        decimal totalValue = 0;
        decimal realizedGain = 0;
        decimal unrealizedGain = 0;

        var assetBreakdown = new List<object>();

        foreach (var asset in assets)
        {
            var txs = transactions
                .Where(t => t.AssetId == asset.Id)
                .OrderBy(t => t.Date)
                .ToList();

            int quantityHeld = 0;
            decimal costBasis = 0;

            foreach (var tx in txs)
            {
                if (tx.Date < startDate)
                    continue;

                if (tx.Quantity > 0)
                {
                    quantityHeld += tx.Quantity;
                    costBasis += tx.Quantity * tx.Price;
                }
                else
                {
                    realizedGain += Math.Abs(tx.Quantity) * tx.Price;
                    quantityHeld += tx.Quantity; // tx.Quantity is negative
                }
            }

            var latestPrice = txs.LastOrDefault()?.Price ?? 0;
            var marketValue = quantityHeld * latestPrice;
            var unrealized = marketValue - costBasis;

            unrealizedGain += unrealized;
            totalValue += marketValue;

            assetBreakdown.Add(new
            {
                Symbol = asset.Symbol,
                Type = asset.Type,
                QuantityHeld = quantityHeld,
                MarketValue = marketValue,
                CostBasis = costBasis,
                UnrealizedGain = unrealized
            });
        }

        var result = new
        {
            PortfolioId = portfolioId,
            StartDate = startDate.ToShortDateString(),
            EndDate = endDate.ToShortDateString(),
            TotalMarketValue = totalValue,
            RealizedGain = realizedGain,
            UnrealizedGain = unrealizedGain,
            AssetBreakdown = assetBreakdown
        };

        return Ok(result);
    }
}
