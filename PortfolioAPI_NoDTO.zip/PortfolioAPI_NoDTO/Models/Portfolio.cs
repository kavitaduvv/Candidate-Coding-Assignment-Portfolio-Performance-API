﻿using System.ComponentModel.DataAnnotations;

namespace PortfolioAPI_NoDTO;

public class Portfolio
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Portfolio name is required.")]
    [StringLength(100, ErrorMessage = "Portfolio name cannot exceed 100 characters.")]
    public string Name { get; set; }
}
