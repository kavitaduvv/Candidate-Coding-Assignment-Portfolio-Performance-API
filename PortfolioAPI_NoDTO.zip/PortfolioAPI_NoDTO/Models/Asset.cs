﻿using System.ComponentModel.DataAnnotations;

namespace PortfolioAPI_NoDTO;

public class Asset
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Symbol is required.")]
    [StringLength(10, ErrorMessage = "Symbol cannot exceed 10 characters.")]
    public string Symbol { get; set; }

    [Required(ErrorMessage = "Asset Type is required.")]
    [StringLength(50)]
    public string Type { get; set; }

    public int PortfolioId { get; set; }
}
