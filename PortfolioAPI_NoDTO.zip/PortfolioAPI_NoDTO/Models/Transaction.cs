﻿using System.ComponentModel.DataAnnotations;

namespace PortfolioAPI_NoDTO;

public class Transaction
{
    public int Id { get; set; }

    public int AssetId { get; set; }

    [Required(ErrorMessage = "Transaction date is required.")]
    public DateTime? Date { get; set; }

    [Range(-1000000, 1000000, ErrorMessage = "Quantity must be between -1,000,000 and 1,000,000.")]
    public int Quantity { get; set; }

    [Range(0.01, 1000000, ErrorMessage = "Price must be greater than 0.")]
    public decimal Price { get; set; }
}
