﻿namespace PortfolioAPI_NoDTO;

public static class SampleDataSeeder
{
    public static void Seed(AppDbContext db)
    {
        if (!db.Portfolios.Any())
        {
            var p1 = new Portfolio { Name = "John Doe Portfolio" };
            var p2 = new Portfolio { Name = "Jane Smith Retirement Fund" };
            db.Portfolios.AddRange(p1, p2);
            db.SaveChanges();

            var a1 = new Asset { Symbol = "AAPL", Type = "Stock", PortfolioId = p1.Id };
            var a2 = new Asset { Symbol = "TSLA", Type = "Stock", PortfolioId = p1.Id };
            db.Assets.AddRange(a1, a2);
            db.SaveChanges();

            db.Transactions.AddRange(
                new Transaction { AssetId = a1.Id, Date = DateTime.UtcNow.AddDays(-10), Quantity = 10, Price = 150 },
                new Transaction { AssetId = a1.Id, Date = DateTime.UtcNow.AddDays(-5), Quantity = -5, Price = 160 },
                new Transaction { AssetId = a2.Id, Date = DateTime.UtcNow.AddDays(-7), Quantity = 8, Price = 700 }
            );
            db.SaveChanges();
        }
    }
}
