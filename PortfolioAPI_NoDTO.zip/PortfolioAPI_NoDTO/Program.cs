using Microsoft.EntityFrameworkCore;
using PortfolioAPI_NoDTO;
using System;

var builder = WebApplication.CreateBuilder(args);

// Register services
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Register SQLite DbContext
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite("Data Source=portfolio.db"));

var app = builder.Build();

// Seed data on startup
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();
    SampleDataSeeder.Seed(db);
}

// Configure middleware
app.UseSwagger();
app.UseSwaggerUI();
app.MapControllers();
app.Run();
