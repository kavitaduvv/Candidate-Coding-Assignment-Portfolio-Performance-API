﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PortfolioAPI_NoDTO;
using PortfolioAPI_NoDTO.Controllers;
using System;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace PortfolioAPI_NoDTO.Tests;

public class TransactionControllerTests
{
    private AppDbContext GetDbContext()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase("TransactionTestDb_" + Guid.NewGuid())
            .Options;
        var context = new AppDbContext(options);

        var p = new Portfolio { Name = "Transaction Portfolio" };
        context.Portfolios.Add(p);
        context.SaveChanges();

        var a = new Asset { Symbol = "NFLX", Type = "Stock", PortfolioId = p.Id };
        context.Assets.Add(a);
        context.SaveChanges();

        return context;
    }

    [Fact]
    public async Task AddTransaction_AddsSuccessfully()
    {
        var context = GetDbContext();
        var controller = new TransactionController(context);
        var assetId = context.Assets.First().Id;

        var tx = new Transaction
        {
            Date = DateTime.UtcNow,
            Quantity = 5,
            Price = 300
        };

        var result = await controller.Create(assetId, tx);
        Assert.IsType<OkObjectResult>(result);
        Assert.Single(context.Transactions);
    }

    [Fact]
    public async Task GetTransactions_ReturnsTransactions()
    {
        var context = GetDbContext();
        var controller = new TransactionController(context);
        var assetId = context.Assets.First().Id;

        context.Transactions.Add(new Transaction
        {
            AssetId = assetId,
            Date = DateTime.UtcNow,
            Quantity = 1,
            Price = 150
        });
        context.SaveChanges();

        var result = await controller.Get(assetId) as OkObjectResult;
        Assert.NotNull(result);
        Assert.Single((System.Collections.IEnumerable)result.Value);
    }

    [Fact]
    public async Task AddTransaction_WithInvalidAsset_StillWorks()
    {
        var context = GetDbContext();
        var controller = new TransactionController(context);
        var invalidAssetId = 999;

        var tx = new Transaction
        {
            Date = DateTime.UtcNow,
            Quantity = 2,
            Price = 200
        };

        var result = await controller.Create(invalidAssetId, tx);
        Assert.IsType<OkObjectResult>(result);
    }
}
