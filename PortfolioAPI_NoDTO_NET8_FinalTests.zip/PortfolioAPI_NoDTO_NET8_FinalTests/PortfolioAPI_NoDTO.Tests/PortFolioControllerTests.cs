﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PortfolioAPI_NoDTO;
using PortfolioAPI_NoDTO.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace PortfolioAPI_NoDTO.Tests;

public class PortfolioControllerTests
{
    private AppDbContext GetDbContext()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase("PortfolioTestDb_" + Guid.NewGuid())
            .Options;

        return new AppDbContext(options);
    }

    [Fact]
    public async Task Create_ReturnsCreated_WhenValid()
    {
        var context = GetDbContext();
        var controller = new PortfolioController(context);

        var newPortfolio = new Portfolio { Name = "Growth Fund" };
        var result = await controller.Create(newPortfolio);

        Assert.IsType<CreatedAtActionResult>(result);
        Assert.Single(context.Portfolios);
    }

    [Fact]
    public async Task Get_ReturnsAllPortfolios()
    {
        var context = GetDbContext();
        context.Portfolios.AddRange(
            new Portfolio { Name = "Retirement" },
            new Portfolio { Name = "Savings" }
        );
        context.SaveChanges();

        var controller = new PortfolioController(context);
        var result = await controller.Get() as OkObjectResult;

        Assert.NotNull(result);
        var portfolios = Assert.IsAssignableFrom<IEnumerable<Portfolio>>(result.Value);
        Assert.Equal(2, portfolios.Count());
    }

    [Fact]
    public async Task Create_ReturnsBadRequest_WhenNameMissing()
    {
        var context = GetDbContext();
        var controller = new PortfolioController(context);

        controller.ModelState.AddModelError("Name", "Required");

        var result = await controller.Create(new Portfolio());

        Assert.IsType<BadRequestObjectResult>(result);
    }

    [Fact]
    public async Task Get_ReturnsEmptyList_WhenNoPortfolios()
    {
        var context = GetDbContext();
        var controller = new PortfolioController(context);

        var result = await controller.Get() as OkObjectResult;

        Assert.NotNull(result);
        var list = Assert.IsAssignableFrom<IEnumerable<Portfolio>>(result.Value);
        Assert.Empty(list);
    }
}
