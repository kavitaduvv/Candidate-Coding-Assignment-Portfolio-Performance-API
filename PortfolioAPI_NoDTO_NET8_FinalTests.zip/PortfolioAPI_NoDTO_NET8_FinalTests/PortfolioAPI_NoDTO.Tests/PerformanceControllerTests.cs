﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PortfolioAPI_NoDTO;
using PortfolioAPI_NoDTO.Controllers;
using System;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace PortfolioAPI_NoDTO.Tests;

public class PerformanceControllerTests
{
    private AppDbContext GetDbContext()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase("PerformanceTestDb_" + Guid.NewGuid())
            .Options;

        var context = new AppDbContext(options);

        var portfolio = new Portfolio { Name = "Performance Portfolio" };
        context.Portfolios.Add(portfolio);
        context.SaveChanges();

        var asset = new Asset
        {
            Symbol = "AAPL",
            Type = "Stock",
            PortfolioId = portfolio.Id
        };
        context.Assets.Add(asset);
        context.SaveChanges();

        context.Transactions.AddRange(
            new Transaction
            {
                AssetId = asset.Id,
                Date = DateTime.UtcNow.AddDays(-10),
                Quantity = 10,
                Price = 100
            },
            new Transaction
            {
                AssetId = asset.Id,
                Date = DateTime.UtcNow.AddDays(-5),
                Quantity = -5,
                Price = 110
            },
            new Transaction
            {
                AssetId = asset.Id,
                Date = DateTime.UtcNow.AddDays(-2),
                Quantity = 5,
                Price = 120
            }
        );
        context.SaveChanges();

        return context;
    }

    [Fact]
    public async Task GetPerformance_ReturnsOkResult_WithValidData()
    {
        var context = GetDbContext();
        var controller = new PerformanceController(context);

        var portfolioId = context.Portfolios.First().Id;
        var startDate = DateTime.UtcNow.AddDays(-15);
        var endDate = DateTime.UtcNow;

        var result = await controller.GetPerformance(portfolioId, startDate, endDate);

        Assert.IsType<OkObjectResult>(result);
        var okResult = result as OkObjectResult;
        Assert.NotNull(okResult.Value);
    }

    [Fact]
    public async Task GetPerformance_ReturnsNotFound_WhenNoAssets()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase("EmptyPortfolioDb_" + Guid.NewGuid())
            .Options;

        var context = new AppDbContext(options);
        var portfolio = new Portfolio { Name = "Empty Portfolio" };
        context.Portfolios.Add(portfolio);
        context.SaveChanges();

        var controller = new PerformanceController(context);
        var result = await controller.GetPerformance(portfolio.Id, DateTime.UtcNow.AddDays(-30), DateTime.UtcNow);

        var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
        Assert.Equal("No assets found for this portfolio.", notFoundResult.Value);
    }

    [Fact]
    public async Task GetPerformance_Handles_NoTransactions()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase("NoTxPortfolioDb_" + Guid.NewGuid())
            .Options;

        var context = new AppDbContext(options);
        var portfolio = new Portfolio { Name = "Portfolio with asset, no tx" };
        context.Portfolios.Add(portfolio);
        context.SaveChanges();

        var asset = new Asset { Symbol = "GOOG", Type = "Stock", PortfolioId = portfolio.Id };
        context.Assets.Add(asset);
        context.SaveChanges();

        var controller = new PerformanceController(context);
        var result = await controller.GetPerformance(portfolio.Id, DateTime.UtcNow.AddMonths(-1), DateTime.UtcNow);

        var okResult = Assert.IsType<OkObjectResult>(result);
        Assert.NotNull(okResult.Value);
    }
}
