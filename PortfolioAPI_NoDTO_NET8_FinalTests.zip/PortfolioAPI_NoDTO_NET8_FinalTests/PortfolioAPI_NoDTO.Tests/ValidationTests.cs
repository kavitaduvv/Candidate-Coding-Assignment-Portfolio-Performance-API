using PortfolioAPI_NoDTO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Xunit;

namespace PortfolioAPI_NoDTO.Tests;

public class ValidationTests
{
    [Fact]
    public void Portfolio_Name_Is_Required()
    {
        var model = new Portfolio { Name = null };
        var context = new ValidationContext(model);
        var results = new List<ValidationResult>();
        var valid = Validator.TryValidateObject(model, context, results, true);

        Assert.False(valid);
        Assert.Contains(results, r => r.MemberNames.Contains("Name"));
    }

    [Fact]
    public void Transaction_With_Zero_Price_Should_Fail()
    {
        var tx = new Transaction
        {
            Date = System.DateTime.UtcNow,
            Quantity = 10,
            Price = 0
        };

        var context = new ValidationContext(tx);
        var results = new List<ValidationResult>();
        var valid = Validator.TryValidateObject(tx, context, results, true);

        Assert.False(valid);
        Assert.Contains(results, r => r.ErrorMessage.Contains("Price"));
    }

      [Fact]
    public void Asset_Symbol_Is_Required()
    {
        var model = new Asset { Symbol = null, Type = "Stock", PortfolioId = 1 };
        var context = new ValidationContext(model);
        var results = new List<ValidationResult>();
        var valid = Validator.TryValidateObject(model, context, results, true);
        Assert.False(valid);
        Assert.Contains(results, r => r.MemberNames.Contains("Symbol"));
    }
    [Fact]
    public void Asset_Type_Is_Required()
    {
        var model = new Asset
        {
            Symbol = "AAPL",
            Type = null, // Invalid
            PortfolioId = 1
        };

        var context = new ValidationContext(model);
        var results = new List<ValidationResult>();
        var valid = Validator.TryValidateObject(model, context, results, true);

        Assert.False(valid);
        Assert.Contains(results, r => r.MemberNames.Contains("Type"));
    }
    [Fact]
    public void Asset_Type_Empty_Should_Fail()
    {
        var model = new Asset
        {
            Symbol = "GOOG",
            Type = "", // Invalid
            PortfolioId = 1
        };

        var context = new ValidationContext(model);
        var results = new List<ValidationResult>();
        var valid = Validator.TryValidateObject(model, context, results, true);

        Assert.False(valid);
        Assert.Contains(results, r => r.MemberNames.Contains("Type"));
    }

    [Fact]
    public void Transaction_Quantity_OutsideRange_ShouldFail()
    {
        var model = new Transaction { AssetId = 1, Date = DateTime.UtcNow, Quantity = 2000000, Price = 100 };
        var context = new ValidationContext(model);
        var results = new List<ValidationResult>();
        var valid = Validator.TryValidateObject(model, context, results, true);
        Assert.False(valid);
        Assert.Contains(results, r => r.MemberNames.Contains("Quantity"));
    }

    [Fact]
    public void Transaction_Price_Zero_ShouldFail()
    {
        var model = new Transaction { AssetId = 1, Date = DateTime.UtcNow, Quantity = 5, Price = 0 };
        var context = new ValidationContext(model);
        var results = new List<ValidationResult>();
        var valid = Validator.TryValidateObject(model, context, results, true);
        Assert.False(valid);
        Assert.Contains(results, r => r.MemberNames.Contains("Price"));
    }

    [Fact]
    public void Portfolio_Name_Too_Long_Should_Fail()
    {
        var model = new Portfolio
        {
            Name = new string('A', 101) // 101 characters
        };

        var context = new ValidationContext(model);
        var results = new List<ValidationResult>();
        var valid = Validator.TryValidateObject(model, context, results, true);

        Assert.False(valid);
        Assert.Contains(results, r => r.MemberNames.Contains("Name"));
    }
    [Fact]
    public void Asset_Symbol_TooLong_Should_Fail()
    {
        var model = new Asset
        {
            Symbol = "TOO_LONG_SYMBOL",  // > 10 chars
            Type = "Stock",
            PortfolioId = 1
        };

        var context = new ValidationContext(model);
        var results = new List<ValidationResult>();
        var isValid = Validator.TryValidateObject(model, context, results, true);

        Assert.False(isValid);
        Assert.Contains(results, r => r.MemberNames.Contains("Symbol"));
    }
    [Fact]
    public void Asset_Symbol_Max10Chars_Should_Pass()
    {
        var model = new Asset
        {
            Symbol = "ABCDEFGHIJ",  // exactly 10 chars
            Type = "Stock",
            PortfolioId = 1
        };

        var context = new ValidationContext(model);
        var results = new List<ValidationResult>();
        var isValid = Validator.TryValidateObject(model, context, results, true);

        Assert.True(isValid);
    }
    [Fact]
    public void Transaction_MissingDate_ShouldFail()
    {
        var model = new Transaction
        {
            AssetId = 1,
            Date = null, // default = DateTime.MinValue
            Quantity = 10,
            Price = 100
        };

        var context = new ValidationContext(model);
        var results = new List<ValidationResult>();
        var isValid = Validator.TryValidateObject(model, context, results, true);

        Assert.False(isValid);
        Assert.Contains(results, r => r.MemberNames.Contains("Date"));
    }

    [Fact]
    public void Transaction_ValidDate_ShouldPass()
    {
        var model = new Transaction
        {
            AssetId = 1,
            Date = DateTime.UtcNow,
            Quantity = 10,
            Price = 100
        };

        var context = new ValidationContext(model);
        var results = new List<ValidationResult>();
        var isValid = Validator.TryValidateObject(model, context, results, true);

        Assert.True(isValid);
    }


}