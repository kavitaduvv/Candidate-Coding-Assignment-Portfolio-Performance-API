﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PortfolioAPI_NoDTO;
using PortfolioAPI_NoDTO.Controllers;
using System;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace PortfolioAPI_NoDTO.Tests;

public class AssetControllerTests
{
    private AppDbContext GetDbContext()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase("AssetTestDb_" + Guid.NewGuid())
            .Options;
        var context = new AppDbContext(options);

        var p = new Portfolio { Name = "Test Portfolio" };
        context.Portfolios.Add(p);
        context.SaveChanges();

        return context;
    }

    [Fact]
    public async Task AddAsset_AddsSuccessfully()
    {
        var context = GetDbContext();
        var portfolio = context.Portfolios.First();
        var controller = new AssetController(context);

        var asset = new Asset { Symbol = "MSFT", Type = "Stock" };
        var result = await controller.Create(portfolio.Id, asset);

        Assert.IsType<OkObjectResult>(result);
        Assert.Single(context.Assets);
    }

    [Fact]
    public async Task GetAssets_ReturnsAssets()
    {
        var context = GetDbContext();
        var controller = new AssetController(context);
        var portfolioId = context.Portfolios.First().Id;

        context.Assets.Add(new Asset { Symbol = "GOOG", Type = "Stock", PortfolioId = portfolioId });
        context.SaveChanges();

        var result = await controller.Get(portfolioId) as OkObjectResult;
        Assert.NotNull(result);
        Assert.Single((System.Collections.IEnumerable)result.Value);
    }

    [Fact]
    public async Task DeleteAsset_ReturnsNotFound_WhenInvalidId()
    {
        var context = GetDbContext();
        var controller = new AssetController(context);

        var result = await controller.Delete(999); // Invalid ID
        Assert.IsType<NotFoundResult>(result);
    }
}
